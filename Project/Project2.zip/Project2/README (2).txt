What works:
-Creating a TaskList
-Opening a TaskList
-Adding a Task to a TaskList
-Removing a Task form a TaskList 
What does not work:
- Error handleing for tempHours and tempMinutes when the user wants to add a task.
	I spent over 2 hours alone trying to figure out what is wrong with the
code, but I could not locate the mistak. A similar code is working just fine,
but the tempHours and tempMinutes just does not.
-I could not locate the .exe!
	I found the .o for the main, but netbeans would not export it to .exe.
I tried to force netbeans to export the .exe by using the Cygwin terminal, and
it was not a success.
TL;DR: All functions in My year works as intended, except for an the error handling for tempHours and tempMinutes.